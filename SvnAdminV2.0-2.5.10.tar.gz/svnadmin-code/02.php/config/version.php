<?php
/*
 * @Author: witersen
 * 
 * @LastEditors: witersen
 * 
 * @Description: QQ:1801168257
 */

/**
 * 当前软件版本信息
 * 用户请不要自行修改 以免影响后续升级检测
 */
return [
    'php' => [
        'lowest' => '5.5.0',
        'highest' => ''
    ],
    'version' => '2.5.9'
];
