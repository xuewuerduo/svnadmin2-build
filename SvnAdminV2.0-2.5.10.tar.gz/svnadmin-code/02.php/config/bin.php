<?php
/*
 * @Author: witersen
 * 
 * @LastEditors: witersen
 * 
 * @Description: QQ:1801168257
 */

return [
    'svn' => '/usr/bin/svn',
    'svnadmin' => '/usr/bin/svnadmin',
    'svnlook' => '/usr/bin/svnlook',
    'svnserve' => '/usr/bin/svnserve',
    'svnversion' => '/usr/bin/svnversion',
    'svnsync' => '/usr/bin/svnsync',
    'svnrdump' => '/usr/bin/svnrdump',
    'svndumpfilter' => '/usr/bin/svndumpfilter',
    'svnmucc' => '/usr/bin/svnmucc',
    'svnauthz-validate' => '/usr/bin/svn-tools/svnauthz-validate',
    'saslauthd' => '/usr/sbin/saslauthd',
    'httpd' => '/usr/sbin/httpd',
    'htpasswd' => '/usr/bin/htpasswd'
];
