<?php
/*
 * @Author: witersen
 * 
 * @LastEditors: witersen
 * 
 * @Description: QQ:1801168257
 */

/*
 * jwt的token模式中的签名
 */
return [
    'signature' => 'QOWIREUQWIOFN',
    'signSeparator' => '|'
];
