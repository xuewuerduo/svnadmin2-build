# view-ui-project

This project is build for Vue.js 2 + vue-router + webpack2 + View UI (iView) 4, just install and run.

## Install
```bush
// install dependencies
npm install
```
## Run
### Development
```bush
// For the first time, run init to create index.html
npm run init
npm run dev
```
### Production(Build)
```bush
npm run build
```

